<script setup lang="ts">
throw new Error("Test error");
</script>

<template></template>