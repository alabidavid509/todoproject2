<template>
    <div class="app">
      <h1>Todo App</h1>
  
      <input v-model="newTodo" placeholder="Add a todo..." />
      <button @click="addTodo">Add</button>
  
      <div class="filters">
        <button @click="filter = 'all'">All</button>
        <button @click="filter = 'active'">Active</button>
        <button @click="filter = 'done'">Completed</button>
      </div>
  
      <ul>
        <li v-for="todo in filteredTodos" :key="todo.id">
          <span
            @click="toggleTodo(todo.id)"
            :style="{ textDecoration: todo.done ? 'line-through' : 'none' }"
          >
            {{ todo.text }}
          </span>
  
          <button @click="deleteTodo(todo.id)">X</button>
        </li>
      </ul>
    </div>
  </template>
  
  <script setup lang="ts">
  import { ref, computed, onMounted, watch } from 'vue'
  
  type Todo = {
    id: number
    text: string
    done: boolean
  }
  
  const newTodo = ref('')
  const todos = ref<Todo[]>([])
  const filter = ref<'all' | 'active' | 'done'>('all')
  
  const addTodo = () => {
    if (!newTodo.value.trim()) return
  
    todos.value.push({
      id: Date.now(),
      text: newTodo.value,
      done: false
    })
  
    newTodo.value = ''
  }
  
  const toggleTodo = (id: number) => {
    const todo = todos.value.find(t => t.id === id)
    if (todo) todo.done = !todo.done
  }
  
  const deleteTodo = (id: number) => {
    todos.value = todos.value.filter(t => t.id !== id)
  }
  
  const filteredTodos = computed(() => {
    if (filter.value === 'active') return todos.value.filter(t => !t.done)
    if (filter.value === 'done') return todos.value.filter(t => t.done)
    return todos.value
  })
  
  // ✅ LocalStorage (important for marks)
  onMounted(() => {
    const saved = localStorage.getItem('todos')
    if (saved) todos.value = JSON.parse(saved)
  })
  
  watch(todos, () => {
    localStorage.setItem('todos', JSON.stringify(todos.value))
  }, { deep: true })
  </script>
  
  <style>
  .app {
    max-width: 400px;
    margin: 50px auto;
    font-family: Arial;
  }
  
  .filters button {
    margin: 5px;
  }
  </style>