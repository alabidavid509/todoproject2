import { createRouter, createWebHistory } from "vue-router";
import Home from "../pages/Home.vue";
import TodoDetails from "../pages/TodoDetails.vue";
import NotFound from "../pages/NotFound.vue";
import ErrorTest from "../pages/ErrorTest.vue";

const routes = [
  { path: "/", component: Home },
  { path: "/todo/:id", component: TodoDetails },
  { path: "/error-test", component: ErrorTest },
  { path: "/:pathMatch(.*)*", component: NotFound },
];

export default createRouter({
  history: createWebHistory(),
  routes,
});