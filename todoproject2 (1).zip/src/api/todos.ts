const BASE_URL = "https://api.oluwasetemi.dev";

export const getTodos = async (page: number) => {
  const res = await fetch(`${BASE_URL}/todos?page=${page}&limit=10`);
  if (!res.ok) throw new Error("Failed to fetch todos");
  return res.json();
};

export const getTodo = async (id: string) => {
  const res = await fetch(`${BASE_URL}/todos/${id}`);
  if (!res.ok) throw new Error("Failed to fetch todo");
  return res.json();
};